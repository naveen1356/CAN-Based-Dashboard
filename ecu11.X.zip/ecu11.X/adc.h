/* 
 * File:   adc.h
 * Author: SANJAY
 *
 * Created on 1 August, 2023, 9:51 PM
 */
#ifndef ADC_H
#define	ADC_H

#define CHANNEL4		0x04
void init_adc(void);
unsigned short read_adc(unsigned char channel);

#endif	/* ADC_H */

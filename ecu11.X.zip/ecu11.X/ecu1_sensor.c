
#include "ecu1_sensor.h"
#include "adc.h"
#include "can.h"
#include "msg_id.h"
#include "uart.h"

#include "digital_keypad_1.h"
#include "clcd.h"
uint16_t adc_val;
    uint16_t new_val;
  
    int idx=0;
    
    
    

uint16_t get_speed()
{
    // Implement the speed function
    
    
    
        
        adc_val=read_adc(CHANNEL4);
        
        new_val = (adc_val * 99)/1023;
        
        
        return new_val;
        
        
}

unsigned char get_gear_pos()
{
    // Implement the gear function
    unsigned int key=read_digital_keypad(STATE_CHANGE);
    if(key==SWITCH1)
        {
            idx=(idx+1)%8;
        }
        else if(key==SWITCH2)
        {
            if(idx<=0) idx=0;
            else idx--;
        }
        return idx;
        

   
    return idx;
}
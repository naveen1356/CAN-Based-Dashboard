#include<xc.h>
#include "adc.h"
#include "can.h"
#include "ecu1_sensor.h"
#include "msg_id.h"
#include "uart.h"
#include "string.h"
#include "clcd.h"

#include "digital_keypad_1.h"

#define _XTAL_FREQ 20000000

static const char *gears[]={"Gn","G1","G2","G3","G4","G4","G5","G6","Gr","CL"};
    void my_itoa(uint16_t speed,char res[])
{
    
    int i = 0, j;
    char temp[10];

    if(speed == 0)
    {
        res[0] = '0';
        res[1] = '\0';
        return;
    }

    while(speed > 0)
    {
        temp[i++] = (speed % 10) + '0';
        speed /= 10;
    }

    for(j = 0; j < i; j++)
        res[j] = temp[i - j - 1];

    res[i] = '\0';

    
}

void main(void)
{
    init_adc();
    init_can();
    init_uart();
    init_clcd();
    init_digital_keypad();
    
    uint8_t speed_str[10];//buffer
        uint16_t speed_val; 
        uint8_t gear_res;
    
    while(1)
    {
        speed_val=get_speed();
         my_itoa(speed_val, speed_str);
        gear_res=get_gear_pos();
        if (gear_res > 7)
        {
            gear_res = 0; 
        }
        
        can_transmit(SPEED_MSG_ID,speed_str, 2);
        can_transmit(GEAR_MSG_ID,gears[gear_res], 2);
        
//        puts("speed: ");
//        puts(speed_str);
//        puts("gear: ");
//        puts(gears[gear_res]);
//        puts("\r\n");
//        __delay_ms(200);
//        clcd_print("SPD:",LINE1(0));
//        clcd_print(speed_str,LINE1(6));
//        clcd_print("gear:",LINE2(0));
//        clcd_print(gears[gear_res],LINE2(6));
       
        
        
        
    }

    
    
    
}
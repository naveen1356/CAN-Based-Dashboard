#include<xc.h>
#include "ecu2_sensor.h"
#include "adc.h"
#include "can.h"
#include "msg_id.h"
#include "digital_keypad_1.h"
#include "uart.h"
#include "string.h"
#include "clcd.h"
#include "matrix_keypad.h"

void my_itoa(uint16_t speed,char res[])
{
    
    int i = 0, j;
    char temp[10];

    if(speed == 0)
    {
        res[0] = '0';
        res[1] = '\0';
        return;
    }

    while(speed > 0)
    {
        temp[i++] = (speed % 10) + '0';
        speed /= 10;
    }

    for(j = 0; j < i; j++)
        res[j] = temp[i - j - 1];

    res[i] = '\0';

    
}
static const char *indicator[6]={"<--","-->","<-->","--"};
void main(void)
{
    //call the functions
    init_adc();
    init_digital_keypad();

    init_can();
    init_clcd();
    
    uint8_t  rpm_res[10];
    unsigned int ind_res;
    uint8_t temp_res[10];
    uint16_t rpm_val;
    
    uint16_t temp_val;
    
    while(1)
    {
    rpm_val=get_rpm();
    my_itoa(rpm_val,rpm_res);
    
    
    ind_res=process_indicator();
    
    temp_val=get_engine_temp();
    my_itoa(temp_val,temp_res);
    
    
    can_transmit(RPM_MSG_ID,rpm_res,4);
    can_transmit(INDICATOR_MSG_ID,indicator[ind_res],5);
    can_transmit(ENG_TEMP_MSG_ID,temp_res,2);
//    clcd_print("R:", LINE2(0));
//    clcd_print(rpm_res, LINE2(2));
//    clcd_print("T:", LINE2(7));
//    clcd_print(temp_res, LINE2(9));
//    clcd_print("I:", LINE1(0));
//    clcd_print(indicator[ind_res], LINE1(6));
    
    
    
    
    
    }
    
    
    
    
    
    
            
    
    
}

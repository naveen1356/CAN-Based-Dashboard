#include "ecu2_sensor.h"
#include "adc.h"
#include "can.h"
#include "msg_id.h"
#include "uart.h"
#include "digital_keypad_1.h"
#include "matrix_keypad.h"

    uint16_t rpm;
    uint16_t res;
    uint16_t adc_reg_val;
    uint16_t temp_res;


uint16_t get_rpm()
{
    rpm= read_adc(CHANNEL4);
    res= (rpm*6000)/1023;
       
        
        return res*100;
   
}

uint16_t get_engine_temp()
{
    //Implement the engine temperature function
    adc_reg_val=read_adc(CHANNEL6);
    temp_res= (adc_reg_val * 5 * 100) / 1023;
    
    
    return temp_res;
    
   
}

unsigned int process_indicator()
{
    //Implement the indicator function
    unsigned char key =read_digital_keypad(STATE_CHANGE);
    
    if(key==SWITCH1)
        {
        return 0;
            
        }
        if(key==SWITCH2)
        {
            return 1;
        }
        if(key==SWITCH3)
        {
          return 2; 
        }
        if(key==SWITCH4){
            return 3;
            
        }
    
    
      
}

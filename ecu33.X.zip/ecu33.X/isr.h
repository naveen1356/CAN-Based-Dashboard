/* 
 * File:   isr.h
 * Author: SANJAY
 *
 * Created on 24 March, 2026, 8:00 PM
 */

#ifndef ISR_H
#define	ISR_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* ISR_H */


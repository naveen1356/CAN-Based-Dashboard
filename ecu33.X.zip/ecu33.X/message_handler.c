#include <xc.h>
#include<stdio.h>
#include "string.h"
#include "message_handler.h"
#include "msg_id.h"
#include "can.h"
#include "clcd.h"


volatile unsigned char led_state = LED_OFF, status = e_ind_off;


void handle_speed_data(uint8_t *data, uint8_t len)
{
    //Implement the speed function
    
    
    clcd_print(data, LINE2(3));
    
    
   


    
}

void handle_gear_data(uint8_t *data, uint8_t len) 
{
    //Implement the gear function
      

    
    clcd_print(data, LINE1(9));
    

    
}

void handle_rpm_data(uint8_t *data, uint8_t len) 
{
    //Implement the rpm function
    
    
    clcd_print(data, LINE2(2));\
    

}

void handle_engine_temp_data(uint8_t *data, uint8_t len) 
{
    //Implement the temperature function
    
    
    clcd_print(data, LINE2(8));
    

}

void handle_indicator_data(uint8_t *data, uint8_t len) 
{
    //Implement the indicator function
   
    
    clcd_print(data, LINE2(11));
    
}

void process_canbus_data() 
{   
    uint16_t msg_id;
      uint8_t data[10];
    uint8_t len;
    //process the CAN bus data
    can_receive(&msg_id,data, &len);
    
   
        switch(msg_id)
        {
            case SPEED_MSG_ID:
            {
                
                handle_speed_data(data, len);
                break;
            }
            
            case GEAR_MSG_ID:
            {
                handle_gear_data(data,len);
                 break;
            }
            case RPM_MSG_ID:
            {
                handle_rpm_data(data,len);
                 break;
            }
            case ENG_TEMP_MSG_ID :
            {
                handle_engine_temp_data(data,len);
                 break;
            }
            case INDICATOR_MSG_ID :
            {
                handle_indicator_data(data,len);
                 break;
            }
            default:
                break;
            
        }
    
    
}
